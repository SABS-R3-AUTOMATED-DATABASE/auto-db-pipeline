# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['auto_db_pipeline']

package_data = \
{'': ['*']}

install_requires = \
['matplotlib>=3.4.3,<4.0.0', 'numpy>=1.20.0,<1.21.0']

setup_kwargs = {
    'name': 'auto-db-pipeline',
    'version': '0.1.0',
    'description': 'SABSR3 automated data extraction project',
    'long_description': None,
    'author': 'Emily Jin, Fabian Spoendlin, Gemma Gordon, Hongyu Qian, Jesse Murray',
    'author_email': None,
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
